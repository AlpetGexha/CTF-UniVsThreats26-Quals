set -eu
cd framework
./framework-cards-bin

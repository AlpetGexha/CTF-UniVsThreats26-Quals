use std::net::TcpStream;
use std::io::{Read, Write};
use std::{error::Error, fs};
use std::env;
use std::time::Duration;

fn read_until(stream: &mut TcpStream, marker: &str, timeout_ms: u64) -> Result<String, Box<dyn Error>> {
    stream.set_read_timeout(Some(Duration::from_millis(500)))?;
    let mut all_data = Vec::new();
    let mut buf = [0u8; 8192];
    let start = std::time::Instant::now();

    loop {
        if start.elapsed().as_millis() > timeout_ms as u128 {
            break;
        }
        match stream.read(&mut buf) {
            Ok(0) => break,
            Ok(n) => {
                all_data.extend_from_slice(&buf[..n]);
                let s = String::from_utf8_lossy(&all_data);
                if s.contains(marker) {
                    break;
                }
            }
            Err(_) => {
                let s = String::from_utf8_lossy(&all_data);
                if s.contains(marker) {
                    break;
                }
            }
        }
    }

    stream.set_read_timeout(Some(Duration::from_secs(30)))?;
    Ok(String::from_utf8_lossy(&all_data).to_string())
}

/// Parse "object(X,Y)" patterns from a string, returning (X, Y) pairs
fn parse_object_ids(text: &str) -> Vec<(u64, u64)> {
    let mut result = Vec::new();
    let mut search = text;
    while let Some(pos) = search.find("object(") {
        let rest = &search[pos + 7..];
        if let Some(end) = rest.find(')') {
            let inner = &rest[..end];
            let parts: Vec<&str> = inner.split(',').collect();
            if parts.len() == 2 {
                if let (Ok(a), Ok(b)) = (
                    parts[0].trim().parse::<u64>(),
                    parts[1].trim().parse::<u64>(),
                ) {
                    result.push((a, b));
                }
            }
        }
        search = &search[pos + 7..];
    }
    result
}

/// Extract "deleted:" section object IDs from a call_function response
fn parse_deleted(response: &str) -> Vec<(u64, u64)> {
    if let Some(del_pos) = response.find("deleted:") {
        let del_section = &response[del_pos..];
        let end = del_section.find("\ngas")
            .or_else(|| del_section.find("\nunchanged"))
            .or_else(|| del_section.find("\nmutated"))
            .unwrap_or(del_section.len());
        parse_object_ids(&del_section[..end])
    } else {
        Vec::new()
    }
}

fn main() -> Result<(), Box<dyn Error>> {
    let host = env::var("HOST").unwrap_or_else(|_| "127.0.0.1".to_string());
    let port = env::var("PORT").unwrap_or_else(|_| "31337".to_string());

    println!("Connecting to {}:{}...", host, port);
    let mut stream = TcpStream::connect(format!("{}:{}", host, port))?;
    stream.set_read_timeout(Some(Duration::from_secs(30)))?;
    stream.set_write_timeout(Some(Duration::from_secs(10)))?;

    let _welcome = read_until(&mut stream, "Select option:", 15000)?;
    println!("Server ready");

    // Step 1: Upload solution module
    stream.write_all(b"1\n")?;
    stream.flush()?;
    let _prompt = read_until(&mut stream, "named address:", 5000)?;
    stream.write_all(b"solution\n")?;
    stream.flush()?;
    let _prompt = read_until(&mut stream, "bytecode", 5000)?;
    let mod_data = fs::read("./solve/build/solution/bytecode_modules/solution.mv")?;
    stream.write_all(&mod_data)?;
    stream.flush()?;
    let response = read_until(&mut stream, "Select option:", 10000)?;
    assert!(response.contains("SUCCESS"), "Module upload failed");
    println!("Module uploaded");

    // TODO: implement your solution here

    // Get flag
    stream.write_all(b"4\n")?;
    stream.flush()?;
    let flag_response = read_until(&mut stream, "Select option:", 10000)?;
    println!("{}", flag_response);

    Ok(())
}

#[derive(Clone)]
enum Param {
    Object(u64, u64),
    Number(&'static str, u64),
    ImmShared(&'static str),
    ObjVec(Vec<(u64, u64)>),
}

fn call_function(
    stream: &mut TcpStream,
    package: &str,
    module: &str,
    function: &str,
    params: &[Param],
) -> Result<String, Box<dyn Error>> {
    stream.write_all(b"3\n")?;
    stream.flush()?;

    let _prompt = read_until(stream, "package name", 5000)?;
    stream.write_all(format!("{}\n", package).as_bytes())?;
    stream.flush()?;

    let _prompt = read_until(stream, "module name", 5000)?;
    stream.write_all(format!("{}\n", module).as_bytes())?;
    stream.flush()?;

    let _prompt = read_until(stream, "function name", 5000)?;
    stream.write_all(format!("{}\n", function).as_bytes())?;
    stream.flush()?;

    let _prompt = read_until(stream, "number of parameters", 5000)?;
    stream.write_all(format!("{}\n", params.len()).as_bytes())?;
    stream.flush()?;

    for param in params {
        let _prompt = read_until(stream, "Enter type", 5000)?;

        match param {
            Param::Object(n1, n2) => {
                stream.write_all(b"object\n")?;
                stream.flush()?;

                let _prompt = read_until(stream, "first number", 5000)?;
                stream.write_all(format!("{}\n", n1).as_bytes())?;
                stream.flush()?;

                let _prompt = read_until(stream, "second number", 5000)?;
                stream.write_all(format!("{}\n", n2).as_bytes())?;
                stream.flush()?;
            }
            Param::Number(num_type, value) => {
                stream.write_all(b"number\n")?;
                stream.flush()?;

                let _prompt = read_until(stream, "number type", 5000)?;
                stream.write_all(format!("{}\n", num_type).as_bytes())?;
                stream.flush()?;

                let _prompt = read_until(stream, "value", 5000)?;
                stream.write_all(format!("{}\n", value).as_bytes())?;
                stream.flush()?;
            }
            Param::ImmShared(addr) => {
                stream.write_all(b"immshared\n")?;
                stream.flush()?;

                let _prompt = read_until(stream, "address", 5000)?;
                stream.write_all(format!("{}\n", addr).as_bytes())?;
                stream.flush()?;
            }
            Param::ObjVec(objects) => {
                stream.write_all(b"object_vector\n")?;
                stream.flush()?;

                let _prompt = read_until(stream, "number of objects", 5000)?;
                stream.write_all(format!("{}\n", objects.len()).as_bytes())?;
                stream.flush()?;

                for (n1, n2) in objects {
                    let _prompt = read_until(stream, "first number", 5000)?;
                    stream.write_all(format!("{}\n", n1).as_bytes())?;
                    stream.flush()?;

                    let _prompt = read_until(stream, "second number", 5000)?;
                    stream.write_all(format!("{}\n", n2).as_bytes())?;
                    stream.flush()?;
                }
            }
        }
    }

    let response = read_until(stream, "Select option:", 15000)?;
    for line in response.lines() {
        if line.contains("SUCCESS") || line.contains("ERROR") || line.contains("Function") {
            println!("    - {}", line.trim());
        }
    }

    Ok(response)
}

use std::collections::HashMap;
use std::env;
use std::error::Error;
use std::io::{Read, Write};
use std::mem::drop;
use std::net::{TcpListener, TcpStream};
use std::path::Path;

use serde_json;
use tokio;

use move_transactional_test_runner::framework::MaybeNamedCompiledModule;
use move_bytecode_source_map::{source_map::SourceMap, utils::source_map_from_file};
use move_binary_format::file_format::CompiledModule;
use move_symbol_pool::Symbol;
use move_core_types::{
    account_address::AccountAddress,
    language_storage::TypeTag,
    runtime_value::MoveValue};

use sui_ctf_framework::NumericalAddress;
use sui_types::base_types::ObjectID;
use sui_transactional_test_runner::{args::SuiValue, test_adapter::FakeID};

macro_rules! handle_err {
    ($stream:expr, $msg:expr, $err:expr) => {{
        let full = format!("[SERVER ERROR] {}: {}", $msg, $err);
        eprintln!("{}", full);
        let _ = $stream.write_all(full.as_bytes());
        let _ = $stream.write_all(b"\n[SERVER] Connection will be closed due to error.\n");
        let _ = $stream.flush();
        drop($stream);
        return Err::<(), Box<dyn std::error::Error>>(full.into());
    }};
}

macro_rules! handle_input_error {
    ($stream:expr, $msg:expr) => {{
        let err_msg = format!("[ERROR] {}\n", $msg);
        eprintln!("{}", err_msg);
        if let Err(e) = $stream.write_all(err_msg.as_bytes()) {
            eprintln!("[SERVER] Failed to send error message: {}", e);
            return Err(e.into());
        }
        let _ = $stream.flush();
    }};
}

macro_rules! read_input_with_timeout {
    ($stream:expr, $buf:expr, $timeout_msg:expr) => {{
        match $stream.read($buf) {
            Ok(0) => {
                eprintln!("[SERVER] Client disconnected");
                return Ok(());
            }
            Ok(n) => n,
            Err(e) => {
                eprintln!("[SERVER] Read error: {}", e);
                handle_input_error!($stream, $timeout_msg);
                return Err(e.into());
            }
        }
    }};
}

async fn handle_client(mut stream: TcpStream) -> Result<(), Box<dyn Error>> {
    stream.set_read_timeout(Some(std::time::Duration::from_secs(300)))?;
    stream.set_write_timeout(Some(std::time::Duration::from_secs(30)))?;

    println!("[SERVER] Client connected with timeouts set");

    // Initialize SuiTestAdapter
    let challenge_modules = vec!["card", "casino_coin", "exchange", "house"];
    let mut deployed_modules: Vec<AccountAddress> = Vec::new();
    let mut module_name_to_address: HashMap<String, AccountAddress> = HashMap::new();

    let named_addresses = vec![
        (
            "challenge".to_string(),
            NumericalAddress::parse_str("0x0")?,
        ),
        (
            "solution".to_string(),
            NumericalAddress::parse_str("0x0")?,
        ),
    ];

    let mut suitf = match sui_ctf_framework::SuiTF::initialize(
        named_addresses,
        Some(vec!["challenger".to_string(), "solver".to_string()]),
    ).await {
        Ok(adapter) => adapter,
        Err(e) => handle_err!(stream, "SuiTF initialization failed", e),
    };

    // Publish all challenge modules
    let mut mncp_modules: Vec<MaybeNamedCompiledModule> = Vec::new();
    for module_name in &challenge_modules {
        let mod_path = format!("./chall/build/challenge/bytecode_modules/{}.mv", module_name);
        let src_path = format!("./chall/build/challenge/debug_info/{}.json", module_name);
        let mod_bytes: Vec<u8> = match std::fs::read(&mod_path) {
            Ok(data) => data,
            Err(e) => handle_err!(stream, format!("Failed to read {}", module_name), e),
        };

        let module: CompiledModule = match CompiledModule::deserialize_with_defaults(&mod_bytes) {
            Ok(data) => data,
            Err(e) => {
                return Err(Box::new(e))
            }
        };
        let named_addr_opt: Option<Symbol> = Some(Symbol::from("challenge"));
        let source_map: Option<SourceMap> = match source_map_from_file(Path::new(&src_path)) {
            Ok(data) => Some(data),
            Err(e) => handle_err!(stream, format!("Deserialization failed for {}", module.name()), e),
        };

        mncp_modules.push(MaybeNamedCompiledModule {
            named_address: named_addr_opt,
            module,
            source_map,
        });
    }

    let chall_dependencies: Vec<String> = Vec::new();
    let chall_addr = match suitf.publish_compiled_module(
        mncp_modules,
        chall_dependencies,
        Some(String::from("challenger")),
    ).await {
        Ok(addr) => addr,
        Err(e) => handle_err!(stream, "Challenge module publish failed", e),
    };

    deployed_modules.push(chall_addr);
    module_name_to_address.insert("challenge".to_string(), chall_addr);
    println!("[SERVER] Challenge modules published at: {:?}", chall_addr);

    // TreasuryHolder is the first shared object from casino_coin::init → always at (1, 0)
    let setup_args: Vec<SuiValue> = vec![
        SuiValue::Object(FakeID::Enumerated(1, 0), None),
    ];
    let setup_type_args: Vec<TypeTag> = Vec::new();

    // Call create_challenge
    let create_tx_num;
    match suitf.call_function(
        chall_addr,
        "exchange",
        "create_challenge",
        setup_args,
        setup_type_args,
        Some("challenger".to_string()),
    ).await {
        Ok(output) => {
            let output_str = output.unwrap_or_default();
            println!("[SERVER] Challenge created. Output: {}", output_str);
            // Parse the tx number from first "object(X," in created section
            let created_section = output_str.split("mutated:").next().unwrap_or(&output_str);
            create_tx_num = if let Some(pos) = created_section.find("object(") {
                let rest = &created_section[pos + 7..];
                rest.split(',').next().and_then(|s| s.trim().parse::<u64>().ok()).unwrap_or(2)
            } else { 2 };
        }
        Err(e) => handle_err!(stream, "Failed to create challenge", e),
    };

    // Probe created objects to find CasinoExchange (the one with claim_balance/is_solved)
    let mut exchange_fake_id = FakeID::Enumerated(create_tx_num, 0); // default to first
    for i in 0..12 {
        let fake_id = FakeID::Enumerated(create_tx_num, i);
        match suitf.view_object(fake_id).await {
            Ok(Some(output)) => {
                let output_str = serde_json::to_string(&output).unwrap_or_default();
                println!("[SERVER] Object ({}, {}): {}", create_tx_num, i, output_str);
                if output_str.contains("claim_balance") || output_str.contains("is_solved") {
                    exchange_fake_id = fake_id;
                    println!("[SERVER] Found CasinoExchange at ({}, {})", create_tx_num, i);
                    break;
                }
            }
            _ => { break; }
        }
    }
    println!("[SERVER] Using CasinoExchange: {:?}", exchange_fake_id);

    // Send welcome message
    let welcome_msg = "[SERVER] Welcome to Andromeda Casino - Cards!\n";
    stream.write_all(welcome_msg.as_bytes())?;

    // Interactive menu loop
    loop {
        let menu = "\n[MENU]\n1. Upload Module\n2. View Object\n3. Call Function\n4. Get Flag\n5. Exit\nSelect option: ";
        stream.write_all(menu.as_bytes())?;
        stream.flush()?;

        let mut choice_buf = [0u8; 10];
        let n = read_input_with_timeout!(stream, &mut choice_buf, "Connection timed out waiting for menu choice");
        let choice = String::from_utf8_lossy(&choice_buf[..n]).trim().to_string();

        if choice.is_empty() {
            handle_input_error!(stream, "Empty input received. Please enter a valid option (1-5)");
            continue;
        }

        match choice.as_str() {
            "1" => {
                // Upload Module
                stream.write_all(b"Enter module name for named address: ")?;
                stream.flush()?;

                let mut name_buf = [0u8; 100];
                let n = read_input_with_timeout!(stream, &mut name_buf, "Timeout waiting for module name");
                let module_name = String::from_utf8_lossy(&name_buf[..n]).trim().to_string();

                if module_name.is_empty() {
                    handle_input_error!(stream, "Module name cannot be empty");
                    continue;
                }

                if module_name.len() > 50 {
                    handle_input_error!(stream, "Module name too long (max 50 characters)");
                    continue;
                }

                stream.write_all(b"Send module bytecode (max 2000 bytes): ")?;
                stream.flush()?;

                let mut module_data = [0u8; 2000];
                let module_size = read_input_with_timeout!(stream, &mut module_data, "Timeout waiting for module bytecode");

                if module_size == 0 {
                    handle_input_error!(stream, "No module bytecode received");
                    continue;
                }

                let mut sol_dependencies: Vec<String> = Vec::new();
                sol_dependencies.push(String::from("challenge"));

                let mut mncp_solution: Vec<MaybeNamedCompiledModule> = Vec::new();
                let module: CompiledModule = match CompiledModule::deserialize_with_defaults(&module_data[..module_size].to_vec()) {
                    Ok(m) => m,
                    Err(e) => {
                        let err_msg = format!("[ERROR] Module deserialization failed: {}\n", e);
                        stream.write_all(err_msg.as_bytes())?;
                        continue;
                    }
                };
                let named_addr_opt: Option<Symbol> = Some(Symbol::from(module_name.as_str()));
                let source_map: Option<SourceMap> = None;

                mncp_solution.push(MaybeNamedCompiledModule {
                    named_address: named_addr_opt,
                    module,
                    source_map,
                });

                match suitf.publish_compiled_module(
                    mncp_solution,
                    sol_dependencies,
                    Some(String::from("solver")),
                ).await {
                    Ok(addr) => {
                        module_name_to_address.insert(module_name.clone(), addr);
                        let success_msg = format!("[SUCCESS] Module '{}' published at: {}\n", module_name, addr);
                        stream.write_all(success_msg.as_bytes())?;
                    }
                    Err(e) => {
                        let err_msg = format!("[ERROR] Module publish failed: {}\n", e);
                        stream.write_all(err_msg.as_bytes())?;
                    }
                };
            }
            "2" => {
                // View Object
                stream.write_all(b"Enter first number for object ID: ")?;
                stream.flush()?;

                let mut num1_buf = [0u8; 20];
                let n = read_input_with_timeout!(stream, &mut num1_buf, "Timeout waiting for first object number");
                let num1_str = String::from_utf8_lossy(&num1_buf[..n]).trim().to_string();

                if num1_str.is_empty() {
                    handle_input_error!(stream, "First number cannot be empty");
                    continue;
                }

                let num1: u64 = match num1_str.parse() {
                    Ok(n) => n,
                    Err(_) => {
                        handle_input_error!(stream, format!("Invalid first number: '{}'", num1_str));
                        continue;
                    }
                };

                stream.write_all(b"Enter second number for object ID: ")?;
                stream.flush()?;

                let mut num2_buf = [0u8; 20];
                let n = read_input_with_timeout!(stream, &mut num2_buf, "Timeout waiting for second object number");
                let num2_str = String::from_utf8_lossy(&num2_buf[..n]).trim().to_string();

                if num2_str.is_empty() {
                    handle_input_error!(stream, "Second number cannot be empty");
                    continue;
                }

                let num2: u64 = match num2_str.parse() {
                    Ok(n) => n,
                    Err(_) => {
                        handle_input_error!(stream, format!("Invalid second number: '{}'", num2_str));
                        continue;
                    }
                };

                match suitf.view_object(FakeID::Enumerated(num1, num2)).await {
                    Ok(Some(output)) => {
                        println!("[SERVER] Object view returned data: {:#?}", output);
                        let output_str = format!("[OBJECT] {}\n", serde_json::to_string_pretty(&output)?);
                        println!("[SERVER] Sending object response: {}", output_str);
                        stream.write_all(output_str.as_bytes())?;
                        stream.write_all(b"\n---END---\n")?;
                        stream.flush()?;

                        let mut ack_buf = [0u8; 10];
                        match stream.read(&mut ack_buf) {
                            Ok(_) => println!("[SERVER] Client acknowledged object response"),
                            Err(e) => println!("[SERVER] Warning: No client ack: {}", e),
                        }
                    }
                    Ok(None) => {
                        stream.write_all(b"[OBJECT] No output\n")?;
                        stream.flush()?;
                    }
                    Err(e) => {
                        let err_msg = format!("[ERROR] Failed to view object: {}\n", e);
                        stream.write_all(err_msg.as_bytes())?;
                        stream.flush()?;
                    }
                }
            }
            "3" => {
                // Call Function
                stream.write_all(b"Enter package name (challenge/solution): ")?;
                stream.flush()?;

                let mut pkg_name_buf = [0u8; 100];
                let n = read_input_with_timeout!(stream, &mut pkg_name_buf, "Timeout waiting for package name");
                let pkg_name = String::from_utf8_lossy(&pkg_name_buf[..n]).trim().to_string();

                if pkg_name.is_empty() {
                    handle_input_error!(stream, "Package name cannot be empty");
                    continue;
                }

                let mod_addr = match module_name_to_address.get(&pkg_name) {
                    Some(addr) => *addr,
                    None => {
                        let keys: Vec<String> = module_name_to_address.keys().cloned().collect();
                        handle_input_error!(stream, format!("Package '{}' not found. Available: {}",
                            pkg_name, keys.join(", ")));
                        continue;
                    }
                };

                stream.write_all(b"Enter module name (e.g. exchange, house, card, solution): ")?;
                stream.flush()?;

                let mut mod_name_buf = [0u8; 100];
                let n = read_input_with_timeout!(stream, &mut mod_name_buf, "Timeout waiting for module name");
                let mod_name = String::from_utf8_lossy(&mod_name_buf[..n]).trim().to_string();

                if mod_name.is_empty() {
                    handle_input_error!(stream, "Module name cannot be empty");
                    continue;
                }

                stream.write_all(b"Enter function name: ")?;
                stream.flush()?;

                let mut func_name_buf = [0u8; 100];
                let n = read_input_with_timeout!(stream, &mut func_name_buf, "Timeout waiting for function name");
                let func_name = String::from_utf8_lossy(&func_name_buf[..n]).trim().to_string();

                if func_name.is_empty() {
                    handle_input_error!(stream, "Function name cannot be empty");
                    continue;
                }

                stream.write_all(b"Enter number of parameters: ")?;
                stream.flush()?;

                let mut param_count_buf = [0u8; 10];
                let n = read_input_with_timeout!(stream, &mut param_count_buf, "Timeout waiting for parameter count");
                let param_count_str = String::from_utf8_lossy(&param_count_buf[..n]).trim().to_string();

                if param_count_str.is_empty() {
                    handle_input_error!(stream, "Parameter count cannot be empty");
                    continue;
                }

                let param_count: usize = match param_count_str.parse() {
                    Ok(n) if n <= 50 => n, // Allow more params for object vectors
                    Ok(n) => {
                        handle_input_error!(stream, format!("Too many parameters: {}. Max is 50", n));
                        continue;
                    }
                    Err(_) => {
                        handle_input_error!(stream, format!("Invalid parameter count: '{}'", param_count_str));
                        continue;
                    }
                };

                let mut args: Vec<SuiValue> = Vec::new();

                for i in 0..param_count {
                    let param_msg = format!("Parameter {} - Enter type (number/object/immshared/object_vector): ", i + 1);
                    stream.write_all(param_msg.as_bytes())?;
                    stream.flush()?;

                    let mut type_buf = [0u8; 30];
                    let n = read_input_with_timeout!(stream, &mut type_buf, "Timeout waiting for parameter type");
                    let param_type = String::from_utf8_lossy(&type_buf[..n]).trim().to_string();

                    if param_type.is_empty() {
                        handle_input_error!(stream, "Parameter type cannot be empty");
                        continue;
                    }

                    match param_type.as_str() {
                        "number" => {
                            stream.write_all(b"Enter number type (u8/u16/u32/u64): ")?;
                            stream.flush()?;

                            let mut num_type_buf = [0u8; 10];
                            let n = stream.read(&mut num_type_buf)?;
                            let num_type = String::from_utf8_lossy(&num_type_buf[..n]).trim().to_string();

                            stream.write_all(b"Enter value: ")?;
                            stream.flush()?;

                            let mut value_buf = [0u8; 20];
                            let n = stream.read(&mut value_buf)?;
                            let value: u64 = match String::from_utf8_lossy(&value_buf[..n]).trim().parse() {
                                Ok(n) => n,
                                Err(_) => {
                                    stream.write_all(b"[ERROR] Invalid value\n")?;
                                    continue;
                                }
                            };

                            match num_type.as_str() {
                                "u8" => args.push(SuiValue::MoveValue(MoveValue::U8(value as u8))),
                                "u16" => args.push(SuiValue::MoveValue(MoveValue::U16(value as u16))),
                                "u32" => args.push(SuiValue::MoveValue(MoveValue::U32(value as u32))),
                                "u64" => args.push(SuiValue::MoveValue(MoveValue::U64(value))),
                                _ => {
                                    stream.write_all(b"[ERROR] Invalid number type\n")?;
                                    continue;
                                }
                            }
                        }
                        "object" => {
                            stream.write_all(b"Enter first number for object ID: ")?;
                            stream.flush()?;

                            let mut num1_buf = [0u8; 20];
                            let n = read_input_with_timeout!(stream, &mut num1_buf, "Timeout waiting for first object number");
                            let num1: u64 = match String::from_utf8_lossy(&num1_buf[..n]).trim().parse() {
                                Ok(n) => n,
                                Err(_) => {
                                    stream.write_all(b"[ERROR] Invalid number\n")?;
                                    continue;
                                }
                            };

                            stream.write_all(b"Enter second number for object ID: ")?;
                            stream.flush()?;

                            let mut num2_buf = [0u8; 20];
                            let n = read_input_with_timeout!(stream, &mut num2_buf, "Timeout waiting for second object number");
                            let num2: u64 = match String::from_utf8_lossy(&num2_buf[..n]).trim().parse() {
                                Ok(n) => n,
                                Err(_) => {
                                    stream.write_all(b"[ERROR] Invalid number\n")?;
                                    continue;
                                }
                            };

                            args.push(SuiValue::Object(FakeID::Enumerated(num1, num2), None));
                        }
                        "immshared" => {
                            // Immutable shared object (e.g. Random at 0x8)
                            stream.write_all(b"Enter object address (hex, e.g. 0x8): ")?;
                            stream.flush()?;

                            let mut addr_buf = [0u8; 100];
                            let n = read_input_with_timeout!(stream, &mut addr_buf, "Timeout waiting for address");
                            let addr_str = String::from_utf8_lossy(&addr_buf[..n]).trim().to_string();

                            match ObjectID::from_hex_literal(&addr_str) {
                                Ok(obj_id) => {
                                    args.push(SuiValue::ImmShared(FakeID::Known(obj_id), None));
                                }
                                Err(_) => {
                                    stream.write_all(b"[ERROR] Invalid address format\n")?;
                                    continue;
                                }
                            }
                        }
                        "object_vector" => {
                            // Vector of objects for play_hand
                            stream.write_all(b"Enter number of objects in vector: ")?;
                            stream.flush()?;

                            let mut vec_len_buf = [0u8; 10];
                            let n = read_input_with_timeout!(stream, &mut vec_len_buf, "Timeout waiting for vector length");
                            let vec_len: usize = match String::from_utf8_lossy(&vec_len_buf[..n]).trim().parse() {
                                Ok(n) => n,
                                Err(_) => {
                                    stream.write_all(b"[ERROR] Invalid length\n")?;
                                    continue;
                                }
                            };

                            let mut obj_vec = Vec::new();
                            for j in 0..vec_len {
                                let obj_msg = format!("Object {} - Enter first number: ", j + 1);
                                stream.write_all(obj_msg.as_bytes())?;
                                stream.flush()?;

                                let mut n1_buf = [0u8; 20];
                                let n = stream.read(&mut n1_buf)?;
                                let n1: u64 = match String::from_utf8_lossy(&n1_buf[..n]).trim().parse() {
                                    Ok(n) => n,
                                    Err(_) => {
                                        stream.write_all(b"[ERROR] Invalid number\n")?;
                                        continue;
                                    }
                                };

                                let obj_msg2 = format!("Object {} - Enter second number: ", j + 1);
                                stream.write_all(obj_msg2.as_bytes())?;
                                stream.flush()?;

                                let mut n2_buf = [0u8; 20];
                                let n = stream.read(&mut n2_buf)?;
                                let n2: u64 = match String::from_utf8_lossy(&n2_buf[..n]).trim().parse() {
                                    Ok(n) => n,
                                    Err(_) => {
                                        stream.write_all(b"[ERROR] Invalid number\n")?;
                                        continue;
                                    }
                                };

                                obj_vec.push((FakeID::Enumerated(n1, n2), None));
                            }
                            args.push(SuiValue::ObjVec(obj_vec));
                        }
                        _ => {
                            handle_input_error!(stream, format!("Invalid parameter type: '{}'. Valid: number, object, immshared, object_vector", param_type));
                            continue;
                        }
                    }
                }

                // Call function
                let type_args: Vec<TypeTag> = Vec::new();

                match suitf.call_function(
                    mod_addr,
                    &mod_name,
                    &func_name,
                    args,
                    type_args,
                    Some("solver".to_string()),
                ).await {
                    Ok(Some(output)) => {
                        let output_msg = format!("[SUCCESS] Function output: {}\n", output);
                        stream.write_all(output_msg.as_bytes())?;
                    }
                    Ok(None) => {
                        stream.write_all(b"[SUCCESS] Function executed (no output)\n")?;
                    }
                    Err(e) => {
                        let err_msg = format!("[ERROR] Function call failed: {}\n", e);
                        stream.write_all(err_msg.as_bytes())?;
                    }
                }
            }
            "4" => {
                // Get Flag - view exchange object and check is_solved field
                let exchange_id = exchange_fake_id;

                match suitf.view_object(exchange_id).await {
                    Ok(Some(output)) => {
                        let output_str = serde_json::to_string(&output).unwrap_or_default();
                        println!("[SERVER] Exchange state: {}", output_str);
                        if output_str.contains("\"is_solved\":\"true") {
                            println!("[SERVER] Correct Solution!");
                            if let Ok(flag) = env::var("FLAG") {
                                let message = format!("[FLAG] Congrats! Flag: {}\n", flag);
                                stream.write_all(message.as_bytes())?;
                            } else {
                                stream.write_all(b"[FLAG] Flag not found, please contact admin\n")?;
                            }
                        } else {
                            stream.write_all(b"[ERROR] Challenge not yet solved\n")?;
                        }
                    }
                    Ok(None) => {
                        stream.write_all(b"[ERROR] Could not check solution\n")?;
                    }
                    Err(e) => {
                        let err_msg = format!("[ERROR] Solution check failed: {}\n", e);
                        stream.write_all(err_msg.as_bytes())?;
                    }
                }
            }
            "5" => {
                stream.write_all(b"[SERVER] Goodbye!\n")?;
                break;
            }
            _ => {
                handle_input_error!(stream, format!("Invalid option: '{}'. Please select 1-5", choice));
            }
        }
    }

    Ok(())
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    let listener = TcpListener::bind("0.0.0.0:31337")?;
    println!("[SERVER] Starting Andromeda Casino - Cards server at port 31337!");

    let local = tokio::task::LocalSet::new();

    for stream in listener.incoming() {
        match stream {
            Ok(stream) => {
                println!("[SERVER] New connection: {}", stream.peer_addr()?);
                let _ = local.run_until(async move {
                    tokio::task::spawn_local(async {
                        if let Err(e) = handle_client(stream).await {
                            eprintln!("[SERVER] Connection Closed. Error: {}", e);
                        }
                    }).await.unwrap();
                }).await;
            }
            Err(e) => {
                println!("[SERVER] Error: {}", e);
            }
        }
    }

    drop(listener);
    Ok(())
}

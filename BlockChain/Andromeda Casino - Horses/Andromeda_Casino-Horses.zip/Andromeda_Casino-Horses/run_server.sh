set -eu
cd framework
./target/release/framework

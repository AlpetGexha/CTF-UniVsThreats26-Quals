set -eu
cd framework-solve
./target/release/framework-solve
